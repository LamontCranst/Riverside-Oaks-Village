fx_version 'cerulean'
game 'gta5'

this_is_a_map "yes"

